import { BaseRoutes } from "@/routes/BaseRoutes";

function App() {
  return (
    <>
      <BaseRoutes />
    </>
  );
}

export default App;
