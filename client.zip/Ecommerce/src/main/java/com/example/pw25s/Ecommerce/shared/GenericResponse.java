package com.example.pw25s.Ecommerce.shared;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GenericResponse {

    private String message = "GenericResponse";

}